package com.overshop.app.buyer.fragments

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.overshop.app.R
import com.overshop.app.repositories.CartRepository
import com.overshop.app.cart.adapters.CartAdapter
import java.text.NumberFormat
import java.util.Locale
import kotlinx.coroutines.launch

/** Muestra el carrito del Comprador y permite revisar sus artículos antes del checkout. */
class CartFragment : Fragment(R.layout.fragment_cart) {

    private lateinit var adapter: CartAdapter
    private lateinit var recyclerCart: RecyclerView
    private lateinit var tvCartCount: TextView
    private lateinit var tvCartEmpty: TextView
    private lateinit var tvCartTotal: TextView
    private lateinit var layoutCartSummary: LinearLayout
    private lateinit var btnCheckout: Button

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerCart = view.findViewById(R.id.recyclerCart)
        tvCartCount = view.findViewById(R.id.tvCartCount)
        tvCartEmpty = view.findViewById(R.id.tvCartEmpty)
        tvCartTotal = view.findViewById(R.id.tvCartTotal)
        layoutCartSummary = view.findViewById(R.id.layoutCartSummary)
        btnCheckout = view.findViewById(R.id.btnCheckout)

        adapter = CartAdapter(
            items = emptyList(),

            onIncrease = { item ->
                viewLifecycleOwner.lifecycleScope.launch {
                    try { CartRepository.updateCloudQuantity(item.product.id, item.size, item.quantity + 1); refreshCart() }
                    catch (_: Exception) { Toast.makeText(requireContext(), "No se pudo actualizar el carrito.", Toast.LENGTH_SHORT).show() }
                }
            },

            onDecrease = { item ->
                viewLifecycleOwner.lifecycleScope.launch {
                    try { CartRepository.updateCloudQuantity(item.product.id, item.size, item.quantity - 1); refreshCart() }
                    catch (_: Exception) { Toast.makeText(requireContext(), "No se pudo actualizar el carrito.", Toast.LENGTH_SHORT).show() }
                }
            },

            onRemove = { item ->
                viewLifecycleOwner.lifecycleScope.launch {
                    try { CartRepository.removeCloudItem(item.product.id, item.size); refreshCart() }
                    catch (_: Exception) { Toast.makeText(requireContext(), "No se pudo quitar el producto.", Toast.LENGTH_SHORT).show() }
                }
            }
        )

        recyclerCart.layoutManager = LinearLayoutManager(requireContext())
        recyclerCart.adapter = adapter

        btnCheckout.setOnClickListener {
            if (CartRepository.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Tu carrito está vacío",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                val intent = android.content.Intent(
                    requireContext(),
                    com.overshop.app.buyer.CheckoutActivity::class.java
                )

                startActivity(intent)
            }
        }

        refreshCart()
    }

    override fun onResume() {
        super.onResume()

        if (::adapter.isInitialized) {
            refreshCart()
        }
    }

    /** Refreshes cloud cart lines and redraws the list, item count, and total. */
    private fun refreshCart() {
        viewLifecycleOwner.lifecycleScope.launch {
        val items = try { CartRepository.loadCloudItems() } catch (_: Exception) {
            Toast.makeText(requireContext(), "No se pudo sincronizar el carrito.", Toast.LENGTH_SHORT).show()
            emptyList()
        }

        adapter.updateItems(items)

        val count = CartRepository.getItemCount()
        tvCartCount.text = "$count productos"

        val empty = items.isEmpty()

        tvCartEmpty.visibility = if (empty) View.VISIBLE else View.GONE
        recyclerCart.visibility = if (empty) View.GONE else View.VISIBLE
        layoutCartSummary.visibility = if (empty) View.GONE else View.VISIBLE

        tvCartTotal.text = formatCurrency(CartRepository.getTotal())
        }
    }

    /** Formats the displayed total using Colombian peso conventions. */
    private fun formatCurrency(amount: Int): String {
        return NumberFormat.getCurrencyInstance(
            Locale.forLanguageTag("es-CO")
        ).format(amount)
    }
}
